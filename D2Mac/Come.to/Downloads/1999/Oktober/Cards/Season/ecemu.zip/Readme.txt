This is a Voyager type of program for Windows 95/NT.
It needs a season interface between the computer and
the satellite receiver. It can decrypt Eurocrypt M and
S2 channels. Use it like SeaMac or voyager. Connect the
season interface to a comport. There is a setting dialog 
box to set the comport.

It logs when a new key is received. It writes channel, index
and time in a file called "log18.txt". You cant see the new
key because it is encrypted. Maybe it doesnt work anymore
because i change the card address just before i posted this.

This program lacks a lot of things. Like a manual, version number
and a Installation program.

I dont know on what receivers it works. I know i works on my
Nokia. I have only implemented the things i needed. I posted
it because maybe it can be useful for someone else.

It stores all data in a file called "Channel.data".

It is written in C++ and is a WIN32 windows application.
