Nordic 3.00 is a small windows program that generates a 1 pic code 
that emulates a Sat-tv smart card.
It enables you to type in new keys with the remote if and 
when they are changed by the tv stations.
It has room for 4 keys for TV3, 4 for TV1000. 9 for Canal+, TV-S, Animal Planet 
or any other EC-S channel in the 00 2B XX serie, 1 for CTV (Ec-M) TV2 N ,
NRK and the TV2 N soccer key . 
All are remotupdatable and possible to overwrite except the keys for TV2 N 
and NRK.
A key that is already working can't be overwritten.

How to update the channels:
Tune in to the channel you want to update.Choose Access/change code and then Access control/New secret code.
Type in the first group of four digits, you might get an answer like 
wrong code. Don't bother it's OK. If you are requested to type the code
once more, do so. Continue with the next code until all seven are done.
The picture will be back in a few seconds.


Is 971209 working with the following channels:
Canal+(If and when the keys get known), TV1000, Cinema, TV3S, TV3DK, TV3N, 
TV6, 3+, VH-1, Z-TV, Nickelodeon, BBC Prime, TCC, Discovery, MTV, Sci-fi, 
Cartoon Network, Eurosport Nordic, CNN, Animal planet, TV-S, NRK1, NRK2 and TV2 N

Version history:

Nordic 3.00: Split the program on two cards to get rid of all the switching 
problems that occurs when you try to put them together on the same card.

Nordic 2.36: Added the new Canal+ key and made some changes regarding the
CTV package

Nordic 2.35: Added the key for TV-S, had to rearrange the Ec-S adresses for 
it to work together with C+.

Nordic 2.34: Three keys for Tv3 08, and two others. Only one for CTV Ec-M 
though. More Pace fixes, no special mode any more, just lock it in Ec-S or 
Ec-M. Fixed a Macab bug as well.

Nordic 2.33: Replaced the TV 3 08 key with the 0C key. Also added Pace 
autoswitchmode to make the card lock in EC-M mode but still recognise the
EC-S channels.

Nordic 2.32: Added the key for Canal+ in Ec-S and Ec-S capability, it took a 
lot of space and there is now only 2 keys for TV3 and TV1000.
The code is very heavily rewritten and this really should be concidered as a 
beta version so if it doesn't work on your receiver, bad luck, if you tell me
though I will try to fix the problems.

Nordic 2.31: Updated with TV3 0C-key

Nordic 2.30: Windows shell added to make life a bit easyer

Nordic 2.20: Updated with Filmnet 09 key.

Nordic 2.19: Only keys that are wrong will be possible to update.
This also overcomes the problem with the access menu on Luxor/Nokia 
that I promised to fix in 2.14.
The 88-command is also improved.

Nordic 2.18: Added routines for testing the 88-command to get away with the 
intermittent scrambling that occurs on some Macabs, it will probably happen 
some time still but I hope it's 1000% better:-) TV3 0B key added.

Nordic 2.17: Patched version of 2.16, not by me.

Nordic 2.16: The keys for NRK and TV2 N soccer added. It now doesn't force
a reset when Macabs ask for the EC-S key but answers the correct way. Some 
more fixes in the I/O-routines as well.

Nordic 2.15: Bug in 2.14 that caused problems on Luxor/Nokia fixed (I hope)

Nordic 2.14: Added the new keys for TV1000, TV3 and TV-S.
Made some more room so that one more key could be fitted for Filmnet,
also made some cleanup and preparations for the NRK key. I had promised 
both my self and others that I would fix the access menu problem on Nokia 
but that space is now used for other things:-( Will see in the future if 
it can be done. 

Nordic 2.13: Fixed the problem on some newer Nokia/Luxors with the mac3
code so now only one version is needed (no seperate code for
Nokia/Macab) Made room for either NRK, Sportkanalen or the TV2N football
key if one of these keys should become known. Had to take away FN key 09
and put TV2N in the program area to do this though:-(

Nordic 2.12: More fixes for losing channels on Mac3-s and Philips.

Nordic 2.11: Bug that erased channels in the Mac3 version fixed, 
four keys for Filmnet also in the Mac3 ver.

Nordic 2.10: Remote update also for TV3 and TV1000, this didn't allow for
all the known keys to be stored but 4 for TV1000 TV3 and Filmnet (3 for 
Filmnet in Mac3 version) and two for the CTV package, one for TV2 N
All are remoteupdatable but the number of possible keys will vary a bit 
depending on which keys are used.

Nordic2.0 (Nordic+): Got room for all the TV3 and TV1000 keys! I was very 
confident that Viasat couldn't overwrite keys in there own cards, 
(unfortunately this was wrong), so I did not attempt to make any remoteupdate
facility for these channels.

Nordic1.0: Stole MM1.6x from Stegen (thanx) and replaced the autoupdate 
for the French channels with more keys for TV3 since there was a huge
interest for this in Scandinavia.


The King of Billeberga?
peter.jonasson@mailbox.swipnet.se

URL: www.billeberga.com
